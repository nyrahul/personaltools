#!/bin/bash

echo "Install minikube pre-requisites"
sudo mkdir /var/lib/minikube/
sudo mkdir /var/lib/minikube/certs/
sudo mkdir /var/lib/minikube/etcd/
sudo mkdir /var/lib/minikube/certs/etcd/

echo "Start Minikube"
minikube start --cpus 4 --memory 4096

echo "Install minikube pre-requisites"
minikube ssh -- sudo mkdir /mnt/gen-script

echo "Minikube IP"
MINIKUBE_IP=$(minikube ip)

echo "Apply CRDs"
echo "Apply ExternalWorkload CRD"
minikube kubectl -- apply -f KubeArmorExternalWorkload.yaml

echo "Apply HostPolicy CRD"
minikube kubectl -- apply -f KubeArmorHostPolicy.yaml

echo "Modify the IP in operator.yaml with minikube IP"
sed -i "s/MINIKUBE_IP/$MINIKUBE_IP/g" kvmsoperator.yaml
minikube kubectl -- apply -f kvmsoperator.yaml
